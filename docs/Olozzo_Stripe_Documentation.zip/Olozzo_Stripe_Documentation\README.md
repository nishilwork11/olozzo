# Olozzo.com documentation

**New developer? Start with the [Developer Setup Guide](PDF/Olozzo_Stripe_Developer_Setup_Guide.pdf).**

| Document | For | Contents |
|---|---|---|
| [Developer Setup Guide](PDF/Olozzo_Stripe_Developer_Setup_Guide.pdf) | Developers | Clone → local setup → Stripe sandbox → test payments |
| [Integration Guide](PDF/Olozzo_Stripe_Live_Integration_Guide.pdf) | Developers | Architecture, findings, test matrix, troubleshooting, references |
| [Live Deployment Guide](PDF/Olozzo_Stripe_Live_Deployment_Guide.pdf) | Developers, DevOps, PM | Blockers, production configuration, webhooks, command catalog, rollback |
| [Production Runbook](PDF/Olozzo_Stripe_Production_Runbook.pdf) | Developers, DevOps | Step-by-step deployment with approval gates |
| [Launch Checklist](PDF/Olozzo_Stripe_Launch_Checklist.pdf) | Client, PM, developer, DevOps | Tasks and sign-offs before live payments |
| [Test/Live Mode Guide](PDF/Olozzo_Stripe_Test_Live_Mode_Guide.pdf) | Developers, DevOps | Sandbox vs live keys, staging, safe switching |
| [Client Setup Guide](PDF/Olozzo_Stripe_Client_Setup_Guide.pdf) | Business owner | Stripe account, verification, bank account, payouts |

Open the documents in the `PDF` folder. The `Markdown` folder holds the editable sources (also in the repository under `docs/`).
